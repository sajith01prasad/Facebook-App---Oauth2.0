
<html>
<head>
<title>Facebook App</title>
 
<style type="text/css">
body {
    background-image: url("wallpaper.jpeg");
    background-size: 1600px 800px;
  	background-repeat: no-repeat;
  
}
    .warning{font-family:Arial, Helvetica, sans-serif;color:#FFF; top:0px;position:relative;left:400px;font-size:40px;}
    .you { position: relative; top: -200px; left: 300px; } 
    .cross { position: absolute; top: -200px; left: 270px; } 
    .letter{position:absolute; top:-200px; left:800px;}
    .content{font-family: Papyrus,fantasy;top:-300px;left:820px;position:relative;font-size:20px; }
    
    
    
    
    .link{
    background-image: url("click.png");
    background-size: 400px 50px;
    width: 400px;
    height:50px;
    top:400px;
    left:500px;
    background-repeat: no-repeat;
    position:relative;
    }
 
    .skull{
    width: 250px;
    height:300px;
    left:700px;
    position:relative;
    
    }
    </style>
    <script>var hidden = false;
var count = 1;
setInterval(function(){
	
    document.getElementById("link").style.visibility= hidden ? "visible" : "hidden";
  
   hidden = !hidden;

},300);


</script>

 
</head>
<body>

<form method="post" action="i.php">
<input type="submit" class="link" value="" id="link"/>
</form>
	<h1 class="warning" id="warning"><b>Who killed you in your previous life?</b></h1>
	<img src="man1.png" class="man"/>
	<img src="skull.png" class="skull"/>
	
 
    </body>
</html>

